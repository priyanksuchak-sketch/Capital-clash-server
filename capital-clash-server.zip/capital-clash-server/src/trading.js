const crypto = require("crypto");
const { pool } = require("./db");
const { calcFees } = require("./fees");

const r2 = (n) => Math.round(n * 100) / 100;

async function withTx(fn) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

// Executes an immediate fill within an already-open transaction. Returns {ok} or {error}.
async function executeFill(client, userId, symbol, side, qty, price) {
  const value = qty * price;
  const fees = calcFees(value, side);
  const { rows: [user] } = await client.query("SELECT cash_balance FROM users WHERE id=$1 FOR UPDATE", [userId]);
  if (!user) return { error: "User not found" };

  if (side === "BUY") {
    const debit = value + fees.total;
    if (Number(user.cash_balance) < debit) return { error: "Not enough cash for this order, including charges" };
    await client.query("UPDATE users SET cash_balance = cash_balance - $1 WHERE id=$2", [debit, userId]);
    const { rows: [h] } = await client.query("SELECT * FROM holdings WHERE user_id=$1 AND symbol=$2 FOR UPDATE", [userId, symbol]);
    if (h) {
      const nq = h.quantity + qty;
      const navg = (Number(h.avg_price) * h.quantity + debit) / nq;
      await client.query("UPDATE holdings SET quantity=$1, avg_price=$2 WHERE user_id=$3 AND symbol=$4", [nq, navg, userId, symbol]);
    } else {
      await client.query("INSERT INTO holdings (user_id,symbol,quantity,avg_price) VALUES ($1,$2,$3,$4)", [userId, symbol, qty, debit / qty]);
    }
  } else {
    const { rows: [h] } = await client.query("SELECT * FROM holdings WHERE user_id=$1 AND symbol=$2 FOR UPDATE", [userId, symbol]);
    if (!h || h.quantity < qty) return { error: "You don't hold enough shares" };
    const credit = value - fees.total;
    await client.query("UPDATE users SET cash_balance = cash_balance + $1 WHERE id=$2", [credit, userId]);
    if (h.quantity === qty) await client.query("DELETE FROM holdings WHERE user_id=$1 AND symbol=$2", [userId, symbol]);
    else await client.query("UPDATE holdings SET quantity=$1 WHERE user_id=$2 AND symbol=$3", [h.quantity - qty, userId, symbol]);
  }

  await client.query(
    `INSERT INTO transactions (id,user_id,symbol,side,quantity,price,fees,kind,net_amount)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [crypto.randomUUID(), userId, symbol, side, qty, price, fees.total, "TRADE",
      side === "BUY" ? -(value + fees.total) : value - fees.total]
  );

  return { ok: true, price, fees };
}

async function placeOrder(userId, market, { symbol, side, orderType, quantity, limitPrice }) {
  const m = market[symbol];
  if (!m) return { error: "Unknown symbol", status: 404 };
  if (m.haltUntil) return { error: `Circuit halt: trading in ${symbol} is paused`, status: 400 };
  const qty = Math.floor(quantity);
  if (!(qty > 0)) return { error: "Quantity must be at least 1", status: 400 };
  if (orderType === "LIMIT" && !(limitPrice > 0)) return { error: "Enter a limit price", status: 400 };

  return withTx(async (client) => {
    if (side === "SELL") {
      const { rows: [h] } = await client.query("SELECT * FROM holdings WHERE user_id=$1 AND symbol=$2", [userId, symbol]);
      const { rows: [pend] } = await client.query(
        `SELECT COALESCE(SUM(quantity),0) AS q FROM orders WHERE user_id=$1 AND symbol=$2 AND side='SELL' AND status='OPEN'`,
        [userId, symbol]
      );
      const have = (h?.quantity || 0) - Number(pend.q);
      if (qty > have) return { error: `You can sell up to ${have} ${symbol}`, status: 400 };
    }

    const price = m.price;
    const marketable = orderType === "MARKET" || (side === "BUY" ? limitPrice >= price : limitPrice <= price);

    if (marketable) {
      const fillPrice = orderType === "MARKET" ? r2(price * (side === "BUY" ? 1.0005 : 0.9995)) : price;
      const r = await executeFill(client, userId, symbol, side, qty, fillPrice);
      if (r.error) return { error: r.error, status: 400 };
      return { status: "FILLED", price: fillPrice, quantity: qty };
    }

    let reserved = 0;
    if (side === "BUY") {
      reserved = r2(limitPrice * qty * 1.004);
      const { rows: [user] } = await client.query("SELECT cash_balance FROM users WHERE id=$1 FOR UPDATE", [userId]);
      if (Number(user.cash_balance) < reserved) return { error: "Not enough cash to hold this limit order", status: 400 };
      await client.query("UPDATE users SET cash_balance = cash_balance - $1 WHERE id=$2", [reserved, userId]);
    }
    const id = crypto.randomUUID();
    await client.query(
      `INSERT INTO orders (id,user_id,symbol,side,order_type,quantity,limit_price,reserved_cash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [id, userId, symbol, side, orderType, qty, limitPrice || null, reserved]
    );
    return { status: "OPEN", orderId: id };
  });
}

async function cancelOrder(userId, orderId) {
  return withTx(async (client) => {
    const { rows: [o] } = await client.query(
      "SELECT * FROM orders WHERE id=$1 AND user_id=$2 AND status='OPEN' FOR UPDATE", [orderId, userId]
    );
    if (!o) return { error: "Order not found", status: 404 };
    await client.query("UPDATE users SET cash_balance = cash_balance + $1 WHERE id=$2", [o.reserved_cash, userId]);
    await client.query("UPDATE orders SET status='CANCELLED' WHERE id=$1", [orderId]);
    return { ok: true };
  });
}

// Runs every tick: checks every open limit order against the latest prices.
async function matchLimitOrders(market, io) {
  const { rows: open } = await pool.query("SELECT * FROM orders WHERE status='OPEN'");
  for (const o of open) {
    const m = market[o.symbol];
    if (!m || m.haltUntil) continue;
    const px = m.price;
    const hit = o.side === "BUY" ? px <= Number(o.limit_price) : px >= Number(o.limit_price);
    if (!hit) continue;
    await withTx(async (client) => {
      const r = await executeFill(client, o.user_id, o.symbol, o.side, o.quantity, px);
      if (r.error) {
        await client.query("UPDATE users SET cash_balance = cash_balance + $1 WHERE id=$2", [o.reserved_cash, o.user_id]);
        await client.query("UPDATE orders SET status='CANCELLED' WHERE id=$1", [o.id]);
        io.to(`user:${o.user_id}`).emit("order:cancelled", { id: o.id, reason: r.error });
      } else {
        await client.query("UPDATE orders SET status='FILLED' WHERE id=$1", [o.id]);
        io.to(`user:${o.user_id}`).emit("order:filled", { id: o.id, symbol: o.symbol, side: o.side, quantity: o.quantity, price: px });
      }
    });
  }
}

// Runs once a quarter (game-time): pays every holder their pro-rata dividend.
async function payDividends(market, io) {
  const { rows } = await pool.query(`
    SELECT h.user_id, h.symbol, h.quantity, s.div_yield
    FROM holdings h JOIN stocks s ON s.symbol = h.symbol
  `);
  const byUser = {};
  rows.forEach((r) => {
    const px = market[r.symbol]?.price;
    if (!px) return;
    const pay = r2(r.quantity * px * (Number(r.div_yield) / 4));
    if (pay > 0) byUser[r.user_id] = (byUser[r.user_id] || 0) + pay;
  });
  await withTx(async (client) => {
    for (const [userId, amount] of Object.entries(byUser)) {
      await client.query("UPDATE users SET cash_balance = cash_balance + $1 WHERE id=$2", [amount, userId]);
      await client.query(
        `INSERT INTO transactions (id,user_id,kind,net_amount) VALUES ($1,$2,'DIVIDEND',$3)`,
        [crypto.randomUUID(), userId, amount]
      );
    }
  });
  Object.entries(byUser).forEach(([userId, amount]) => io.to(`user:${userId}`).emit("dividend", { amount }));
}

module.exports = { executeFill, placeOrder, cancelOrder, matchLimitOrders, payDividends, withTx };
