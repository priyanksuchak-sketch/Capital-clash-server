const crypto = require("crypto");
const { pool } = require("./db");
const { BIZ } = require("./gameData");
const { withTx } = require("./trading");

async function buyBusiness(userId, typeId) {
  const def = BIZ[typeId];
  if (!def) return { error: "Unknown business type", status: 400 };
  return withTx(async (client) => {
    const { rows: [user] } = await client.query("SELECT cash_balance FROM users WHERE id=$1 FOR UPDATE", [userId]);
    if (Number(user.cash_balance) < def.cost) return { error: `You need ₹${Math.round(def.cost).toLocaleString("en-IN")}`, status: 400 };
    const id = crypto.randomUUID();
    await client.query("UPDATE users SET cash_balance = cash_balance - $1 WHERE id=$2", [def.cost, userId]);
    await client.query(
      `INSERT INTO businesses (id,user_id,type_id,level,efficiency,invested_total,company_cash)
       VALUES ($1,$2,$3,1,75,$4,0)`,
      [id, userId, typeId, def.cost]
    );
    return { ok: true, id };
  });
}

async function upgradeBusiness(userId, id, kind) {
  return withTx(async (client) => {
    const { rows: [b] } = await client.query("SELECT * FROM businesses WHERE id=$1 AND user_id=$2 FOR UPDATE", [id, userId]);
    if (!b) return { error: "Business not found", status: 404 };
    const def = BIZ[b.type_id];
    if (kind === "eff" && b.efficiency >= 100) return { error: "Already at maximum efficiency", status: 400 };
    const cost = kind === "level" ? def.cost * 0.5 * b.level : def.cost * 0.04;
    const { rows: [user] } = await client.query("SELECT cash_balance FROM users WHERE id=$1 FOR UPDATE", [userId]);
    if (Number(user.cash_balance) < cost) return { error: `You need ₹${Math.round(cost).toLocaleString("en-IN")}`, status: 400 };
    await client.query("UPDATE users SET cash_balance = cash_balance - $1 WHERE id=$2", [cost, userId]);
    if (kind === "level") {
      await client.query("UPDATE businesses SET level = level+1, invested_total = invested_total+$1 WHERE id=$2", [cost, id]);
    } else {
      await client.query("UPDATE businesses SET efficiency = LEAST(100, efficiency+5), invested_total = invested_total+$1 WHERE id=$2", [cost, id]);
    }
    return { ok: true };
  });
}

async function withdrawBusiness(userId, id) {
  return withTx(async (client) => {
    const { rows: [b] } = await client.query("SELECT * FROM businesses WHERE id=$1 AND user_id=$2 FOR UPDATE", [id, userId]);
    if (!b) return { error: "Business not found", status: 404 };
    if (Number(b.company_cash) <= 0) return { error: "No company cash to withdraw", status: 400 };
    await client.query("UPDATE users SET cash_balance = cash_balance + $1 WHERE id=$2", [b.company_cash, userId]);
    await client.query("UPDATE businesses SET company_cash = 0 WHERE id=$1", [id]);
    return { ok: true };
  });
}

// Runs every 3 ticks ("1 game day") for every business owned by every player.
async function tickBusinesses(activeEvents) {
  const { rows } = await pool.query("SELECT * FROM businesses");
  if (rows.length === 0) return;
  await withTx(async (client) => {
    for (const b of rows) {
      const def = BIZ[b.type_id];
      const mult = activeEvents.reduce((m, e) => m * (e.biz[b.type_id] || 1), 1);
      const noise = def.volatile ? 0.2 + Math.random() * 1.6 : 0.95 + Math.random() * 0.1;
      const rev = def.rev * b.level * (b.efficiency / 100) * mult * noise;
      const net = rev - def.opex * b.level;
      await client.query("UPDATE businesses SET company_cash = company_cash + $1, last_net=$2 WHERE id=$3", [net, net, b.id]);
    }
  });
}

module.exports = { buyBusiness, upgradeBusiness, withdrawBusiness, tickBusinesses };
