// Wraps an async Express handler so a rejected promise reaches next(err)
// instead of crashing the process or hanging the request.
const ah = (fn) => (req, res, next) => fn(req, res, next).catch(next);

module.exports = { ah };
