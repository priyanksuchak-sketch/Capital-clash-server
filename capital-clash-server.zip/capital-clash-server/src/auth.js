const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const db = require("./db");

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const START_CASH = 1000000;

function signup(username, password) {
  const exists = db.prepare("SELECT id FROM users WHERE username = ?").get(username);
  if (exists) throw Object.assign(new Error("That username is taken"), { status: 409 });
  const id = crypto.randomUUID();
  const hash = bcrypt.hashSync(password, 10);
  db.prepare("INSERT INTO users (id, username, password_hash, cash_balance) VALUES (?,?,?,?)")
    .run(id, username, hash, START_CASH);
  return { id, username };
}

function login(username, password) {
  const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash))
    throw Object.assign(new Error("Invalid username or password"), { status: 401 });
  return user;
}

function makeToken(user) {
  return jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: "30d" });
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing token" });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.userId = payload.sub;
    req.username = payload.username;
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

module.exports = { signup, login, makeToken, requireAuth, JWT_SECRET };
