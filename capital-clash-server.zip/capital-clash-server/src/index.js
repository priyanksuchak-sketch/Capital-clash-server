require("dotenv").config();
const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");

const { JWT_SECRET, requireAuth } = require("./auth");
const authRoutes = require("./routes/auth");
const meRoutes = require("./routes/me");
const marketRoutes = require("./routes/market");
const orderRoutes = require("./routes/orders");
const businessRoutes = require("./routes/businesses");
const auctionRoutes = require("./routes/auctions");
const leaderboardRoutes = require("./routes/leaderboard");
const { createGameLoop } = require("./gameLoop");

async function main() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  const server = http.createServer(app);
  const io = new Server(server, { cors: { origin: "*" } });

  // The loop connects to Postgres, creates tables if needed, seeds the
  // stock list, and starts ticking once a second.
  const loop = await createGameLoop(io);

  // Optional auth on the socket handshake: logged-in players join a private
  // room for order fills / dividends / auction wins; anonymous connections
  // can still watch the live market and leaderboard.
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (token) {
      try {
        const payload = jwt.verify(token, JWT_SECRET);
        socket.userId = payload.sub;
        socket.username = payload.username;
      } catch {
        // invalid/expired token: fall through as anonymous rather than reject
      }
    }
    next();
  });

  io.on("connection", (socket) => {
    if (socket.userId) socket.join(`user:${socket.userId}`);
    socket.emit("market:snapshot", { t: loop.getTick(), market: loop.getMarket() });
  });

  app.get("/health", (req, res) => res.json({ ok: true, t: loop.getTick() }));
  app.use("/api/auth", authRoutes);
  app.use("/api/me", requireAuth, meRoutes());
  app.use("/api/market", marketRoutes(loop));
  app.use("/api/orders", requireAuth, orderRoutes(loop));
  app.use("/api/businesses", requireAuth, businessRoutes());
  app.use("/api/auctions", auctionRoutes(loop));
  app.use("/api/leaderboard", leaderboardRoutes(loop));

  // Centralized error handler — every route above forwards failures here
  // via the `ah()` wrapper instead of crashing the process.
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    console.error(err);
    res.status(err.status || 500).json({ error: err.message || "Server error" });
  });

  const PORT = process.env.PORT || 4000;
  server.listen(PORT, () => console.log(`Capital Clash server listening on :${PORT}`));
}

main().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
