const express = require("express");
const { computeLeaderboard } = require("../leaderboard");
const { ah } = require("../utils");

module.exports = (loop) => {
  const router = express.Router();

  router.get("/", ah(async (req, res) => {
    res.json({ leaderboard: await computeLeaderboard(loop.getMarket()) });
  }));

  return router;
};
