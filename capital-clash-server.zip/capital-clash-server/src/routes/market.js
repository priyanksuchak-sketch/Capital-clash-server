const express = require("express");

module.exports = (loop) => {
  const router = express.Router();

  router.get("/", (req, res) => {
    res.json({ t: loop.getTick(), market: loop.getMarket() });
  });

  return router;
};
