const express = require("express");
const { pool } = require("../db");
const { BIZ } = require("../gameData");
const { buyBusiness, upgradeBusiness, withdrawBusiness } = require("../business");
const { ah } = require("../utils");

module.exports = () => {
  const router = express.Router();

  router.get("/catalog", (req, res) => res.json({ catalog: BIZ }));

  router.get("/", ah(async (req, res) => {
    const { rows } = await pool.query("SELECT * FROM businesses WHERE user_id=$1", [req.userId]);
    res.json({ businesses: rows });
  }));

  router.post("/", ah(async (req, res) => {
    const result = await buyBusiness(req.userId, req.body?.type);
    if (result.error) return res.status(result.status || 400).json({ error: result.error });
    res.json(result);
  }));

  router.post("/:id/upgrade", ah(async (req, res) => {
    const result = await upgradeBusiness(req.userId, req.params.id, req.body?.kind);
    if (result.error) return res.status(result.status || 400).json({ error: result.error });
    res.json(result);
  }));

  router.post("/:id/withdraw", ah(async (req, res) => {
    const result = await withdrawBusiness(req.userId, req.params.id);
    if (result.error) return res.status(result.status || 400).json({ error: result.error });
    res.json(result);
  }));

  return router;
};
