const express = require("express");
const { signup, login, makeToken } = require("../auth");
const { ah } = require("../utils");

const router = express.Router();

router.post("/signup", ah(async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password || password.length < 6) {
    return res.status(400).json({ error: "Username and a password of at least 6 characters are required" });
  }
  const user = await signup(username.trim(), password);
  res.json({ token: makeToken(user), username: user.username });
}));

router.post("/login", ah(async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "Username and password are required" });
  const user = await login(username, password);
  res.json({ token: makeToken(user), username: user.username });
}));

module.exports = router;
