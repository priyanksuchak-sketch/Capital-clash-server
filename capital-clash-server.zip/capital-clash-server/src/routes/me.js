const express = require("express");
const { pool } = require("../db");
const { ah } = require("../utils");

module.exports = () => {
  const router = express.Router();

  router.get("/", ah(async (req, res) => {
    const { rows: [user] } = await pool.query("SELECT username, cash_balance FROM users WHERE id=$1", [req.userId]);
    if (!user) return res.status(404).json({ error: "User not found" });
    const { rows: holdings } = await pool.query("SELECT * FROM holdings WHERE user_id=$1", [req.userId]);
    const { rows: businesses } = await pool.query("SELECT * FROM businesses WHERE user_id=$1", [req.userId]);
    const { rows: orders } = await pool.query("SELECT * FROM orders WHERE user_id=$1 AND status='OPEN'", [req.userId]);
    res.json({
      username: user.username,
      cashBalance: Number(user.cash_balance),
      holdings,
      businesses,
      orders,
    });
  }));

  return router;
};
