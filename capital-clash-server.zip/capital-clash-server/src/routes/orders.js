const express = require("express");
const { pool } = require("../db");
const { placeOrder, cancelOrder } = require("../trading");
const { ah } = require("../utils");

module.exports = (loop) => {
  const router = express.Router();

  router.get("/", ah(async (req, res) => {
    const { rows: orders } = await pool.query("SELECT * FROM orders WHERE user_id=$1 AND status='OPEN'", [req.userId]);
    res.json({ orders });
  }));

  router.post("/", ah(async (req, res) => {
    const result = await placeOrder(req.userId, loop.getMarket(), req.body || {});
    if (result.error) return res.status(result.status || 400).json({ error: result.error });
    res.json(result);
  }));

  router.delete("/:id", ah(async (req, res) => {
    const result = await cancelOrder(req.userId, req.params.id);
    if (result.error) return res.status(result.status || 400).json({ error: result.error });
    res.json(result);
  }));

  return router;
};
