const express = require("express");
const { pool } = require("../db");
const { placeBid } = require("../auctions");
const { requireAuth } = require("../auth");
const { ah } = require("../utils");

module.exports = (loop) => {
  const router = express.Router();

  router.get("/", ah(async (req, res) => {
    const { rows } = await pool.query("SELECT * FROM auctions WHERE status='OPEN'");
    res.json({ t: loop.getTick(), auctions: rows });
  }));

  router.post("/:id/bid", requireAuth, ah(async (req, res) => {
    const amount = Math.round(Number(req.body?.amount));
    if (!(amount > 0)) return res.status(400).json({ error: "Enter a bid amount" });
    const result = await placeBid(req.userId, req.username, req.params.id, amount, loop.getTick());
    if (result.error) return res.status(result.status || 400).json({ error: result.error });
    res.json(result);
  }));

  return router;
};
