const { pool } = require("./db");

async function computeLeaderboard(market, limit = 20) {
  const { rows: users } = await pool.query("SELECT id, username, cash_balance FROM users");
  const { rows: holdings } = await pool.query("SELECT * FROM holdings");
  const { rows: businesses } = await pool.query("SELECT * FROM businesses");

  const stockValue = {}, bizValue = {};
  holdings.forEach((h) => {
    const px = market[h.symbol]?.price || 0;
    stockValue[h.user_id] = (stockValue[h.user_id] || 0) + h.quantity * px;
  });
  businesses.forEach((b) => {
    bizValue[b.user_id] = (bizValue[b.user_id] || 0) + Number(b.invested_total) + Number(b.company_cash);
  });

  return users
    .map((u) => ({
      username: u.username,
      netWorth: Math.round(Number(u.cash_balance) + (stockValue[u.id] || 0) + (bizValue[u.id] || 0)),
    }))
    .sort((a, b) => b.netWorth - a.netWorth)
    .slice(0, limit);
}

module.exports = { computeLeaderboard };
