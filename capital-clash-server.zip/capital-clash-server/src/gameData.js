const STOCKS = [
  { s: "RELIANCE", n: "Reliance Industries", sec: "Energy", p: 2900, div: 0.008 },
  { s: "TATAPOWER", n: "Tata Power", sec: "Energy", p: 420, div: 0.012 },
  { s: "TCS", n: "Tata Consultancy", sec: "IT", p: 4000, div: 0.018 },
  { s: "INFY", n: "Infosys", sec: "IT", p: 1700, div: 0.022 },
  { s: "HDFCBANK", n: "HDFC Bank", sec: "Finance", p: 1650, div: 0.01 },
  { s: "TATAMOTORS", n: "Tata Motors", sec: "Auto", p: 950, div: 0.004 },
  { s: "DLF", n: "DLF", sec: "Realty", p: 800, div: 0.006 },
  { s: "ADANIPORTS", n: "Adani Ports", sec: "Trade", p: 1400, div: 0.009 },
  { s: "ITC", n: "ITC Limited", sec: "FMCG", p: 460, div: 0.03 },
  { s: "SUNTV", n: "Sun TV Network", sec: "Media", p: 520, div: 0.02 },
];

const BIZ = {
  solar: { name: "Solar energy farm", cost: 800000, rev: 14000, opex: 4000 },
  taxi: { name: "Ride-hailing agency", cost: 350000, rev: 6500, opex: 2500 },
  trade: { name: "Import-export house", cost: 1500000, rev: 26000, opex: 9000 },
  tech: { name: "Tech startup", cost: 2500000, rev: 45000, opex: 18000, volatile: true },
  realty: { name: "Real estate agency", cost: 6000000, rev: 100000, opex: 40000 },
};

const EVENTS = [
  { text: "Government announces a solar subsidy scheme", stock: { Energy: 0.03 }, biz: { solar: 1.4 }, dur: 40 },
  { text: "RBI raises repo rate; realty and banks slide", stock: { Realty: -0.03, Finance: -0.015 }, biz: { realty: 0.8 }, dur: 40 },
  { text: "Fuel prices spike, squeezing ride-hailing margins", stock: { Auto: -0.015 }, biz: { taxi: 0.75 }, dur: 35 },
  { text: "Port congestion clears; export orders surge", stock: { Trade: 0.025 }, biz: { trade: 1.35 }, dur: 40 },
  { text: "IT majors win record deals; startup funding rebounds", stock: { IT: 0.03 }, biz: { tech: 1.5 }, dur: 40 },
  { text: "SEBI tightens derivatives rules; sentiment cools", stock: { IT: -0.01, Finance: -0.012, Energy: -0.01, Auto: -0.01, Realty: -0.01, Trade: -0.01 }, biz: {}, dur: 20 },
  { text: "IPL season kicks off; broadcasters and FMCG brands ramp up ad spend", stock: { Media: 0.035, FMCG: 0.02 }, biz: {}, dur: 45 },
  { text: "Festive season shopping boosts retail and auto sales", stock: { Auto: 0.03, Trade: 0.02, Realty: 0.015 }, biz: { trade: 1.3 }, dur: 40 },
];

const AUC_CATALOG = [
  { cat: "Art", name: "Bengal School watercolour, 1920s", fair: 4500000 },
  { cat: "Art", name: "Rajasthani court miniature, 18th c.", fair: 2200000 },
  { cat: "Coins", name: "Gold mohur, Mughal mint", fair: 1800000 },
  { cat: "Coins", name: "Independence-year proof rupee set", fair: 800000 },
  { cat: "Timepiece", name: "Perpetual-calendar wristwatch, 1968", fair: 3200000 },
  { cat: "Timepiece", name: "Swiss pocket chronometer, 1910", fair: 1500000 },
];

module.exports = { STOCKS, BIZ, EVENTS, AUC_CATALOG };
