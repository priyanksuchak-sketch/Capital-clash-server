const { Pool } = require("pg");

// Neon/Supabase both require SSL. For a local Postgres without SSL, set PGSSL=false.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "false" ? false : { rejectUnauthorized: false },
});

async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      cash_balance NUMERIC NOT NULL DEFAULT 1000000,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS stocks (
      symbol TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      sector TEXT NOT NULL,
      price NUMERIC NOT NULL,
      div_yield NUMERIC NOT NULL DEFAULT 0.01,
      session_open NUMERIC NOT NULL,
      halt_until INTEGER
    );

    CREATE TABLE IF NOT EXISTS holdings (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      symbol TEXT NOT NULL REFERENCES stocks(symbol),
      quantity INTEGER NOT NULL,
      avg_price NUMERIC NOT NULL,
      PRIMARY KEY (user_id, symbol)
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      symbol TEXT NOT NULL,
      side TEXT NOT NULL,
      order_type TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      limit_price NUMERIC,
      status TEXT NOT NULL DEFAULT 'OPEN',
      reserved_cash NUMERIC NOT NULL DEFAULT 0,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      symbol TEXT,
      side TEXT,
      quantity INTEGER,
      price NUMERIC,
      fees NUMERIC DEFAULT 0,
      kind TEXT NOT NULL,
      net_amount NUMERIC NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS businesses (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type_id TEXT NOT NULL,
      level INTEGER NOT NULL DEFAULT 1,
      efficiency INTEGER NOT NULL DEFAULT 75,
      invested_total NUMERIC NOT NULL,
      company_cash NUMERIC NOT NULL DEFAULT 0,
      last_net NUMERIC NOT NULL DEFAULT 0,
      acquired_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS auctions (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL,
      item_name TEXT NOT NULL,
      meta JSONB,
      fair_value NUMERIC NOT NULL,
      current_bid NUMERIC NOT NULL,
      leader_user_id TEXT,
      leader_name TEXT,
      status TEXT NOT NULL DEFAULT 'OPEN',
      ends_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_orders_open ON orders(symbol, status);
    CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_biz_user ON businesses(user_id);
    CREATE INDEX IF NOT EXISTS idx_auction_open ON auctions(status, ends_at);
  `);
}

module.exports = { pool, init };
