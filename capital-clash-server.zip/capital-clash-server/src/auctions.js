const crypto = require("crypto");
const { pool } = require("./db");
const { AUC_CATALOG, STOCKS } = require("./gameData");
const { withTx } = require("./trading");

async function spawnAuction(t, market) {
  const useShares = Math.random() < 0.25;
  const id = crypto.randomUUID();
  const endsAt = t + 40 + Math.floor(Math.random() * 50);
  if (useShares) {
    const st = STOCKS[Math.floor(Math.random() * STOCKS.length)];
    const qty = [100, 250, 400][Math.floor(Math.random() * 3)];
    const fair = Math.round(market[st.s].price * qty * 0.92);
    await pool.query(
      `INSERT INTO auctions (id,category,item_name,meta,fair_value,current_bid,status,ends_at)
       VALUES ($1,$2,$3,$4,$5,$6,'OPEN',$7)`,
      [id, "Repossessed shares", `${qty} ${st.s} shares`, JSON.stringify({ symbol: st.s, qty }),
        fair, Math.round(fair * 0.45), endsAt]
    );
  } else {
    const tpl = AUC_CATALOG[Math.floor(Math.random() * AUC_CATALOG.length)];
    await pool.query(
      `INSERT INTO auctions (id,category,item_name,fair_value,current_bid,status,ends_at)
       VALUES ($1,$2,$3,$4,$5,'OPEN',$6)`,
      [id, tpl.cat, tpl.name, tpl.fair, Math.round(tpl.fair * 0.45), endsAt]
    );
  }
}

async function seedAuctionIfNeeded(t, market) {
  const { rows: [{ c }] } = await pool.query("SELECT COUNT(*)::int c FROM auctions WHERE status='OPEN'");
  for (let i = c; i < 4; i++) await spawnAuction(t, market);
}

function minBid(a) {
  return a.leader_user_id ? Math.ceil(Number(a.current_bid) * 1.05) : Number(a.current_bid);
}

// Real players bid against each other here — no AI opponents in the
// multiplayer version, since the whole point is a live counterparty.
async function placeBid(userId, username, auctionId, amount, t) {
  return withTx(async (client) => {
    const { rows: [a] } = await client.query("SELECT * FROM auctions WHERE id=$1 AND status='OPEN' FOR UPDATE", [auctionId]);
    if (!a) return { error: "Auction is not open", status: 404 };
    if (t >= a.ends_at) return { error: "Auction has closed", status: 400 };
    if (!(amount >= minBid(a))) return { error: `Minimum bid is ₹${minBid(a).toLocaleString("en-IN")}`, status: 400 };
    const { rows: [user] } = await client.query("SELECT cash_balance FROM users WHERE id=$1 FOR UPDATE", [userId]);
    const heldByMe = a.leader_user_id === userId ? Number(a.current_bid) : 0;
    const charge = amount - heldByMe;
    if (Number(user.cash_balance) < charge) return { error: "Not enough cash for this bid", status: 400 };

    if (a.leader_user_id && a.leader_user_id !== userId) {
      await client.query("UPDATE users SET cash_balance = cash_balance + $1 WHERE id=$2", [a.current_bid, a.leader_user_id]);
    }
    await client.query("UPDATE users SET cash_balance = cash_balance - $1 WHERE id=$2", [charge, userId]);
    const newEndsAt = a.ends_at - t <= 6 ? t + 6 : a.ends_at; // anti-snipe
    await client.query(
      "UPDATE auctions SET current_bid=$1, leader_user_id=$2, leader_name=$3, ends_at=$4 WHERE id=$5",
      [amount, userId, username, newEndsAt, auctionId]
    );
    return { ok: true };
  });
}

// Runs every tick: settles any auction whose clock has run out.
async function resolveAuctions(market, t, io) {
  const { rows: expired } = await pool.query("SELECT * FROM auctions WHERE status='OPEN' AND ends_at<=$1", [t]);
  for (const a of expired) {
    await withTx(async (client) => {
      await client.query("UPDATE auctions SET status='SETTLED' WHERE id=$1", [a.id]);
      if (a.leader_user_id) {
        if (a.category === "Repossessed shares") {
          const meta = a.meta; // node-postgres parses JSONB automatically
          const { rows: [h] } = await client.query(
            "SELECT * FROM holdings WHERE user_id=$1 AND symbol=$2 FOR UPDATE", [a.leader_user_id, meta.symbol]
          );
          if (h) {
            const nq = h.quantity + meta.qty;
            await client.query(
              "UPDATE holdings SET quantity=$1, avg_price=$2 WHERE user_id=$3 AND symbol=$4",
              [nq, (Number(h.avg_price) * h.quantity + Number(a.current_bid)) / nq, a.leader_user_id, meta.symbol]
            );
          } else {
            await client.query(
              "INSERT INTO holdings (user_id,symbol,quantity,avg_price) VALUES ($1,$2,$3,$4)",
              [a.leader_user_id, meta.symbol, meta.qty, Number(a.current_bid) / meta.qty]
            );
          }
        }
        io.to(`user:${a.leader_user_id}`).emit("auction:won", { name: a.item_name, amount: Number(a.current_bid) });
      }
    });
    await spawnAuction(t, market);
  }
}

module.exports = { seedAuctionIfNeeded, placeBid, resolveAuctions, minBid };
