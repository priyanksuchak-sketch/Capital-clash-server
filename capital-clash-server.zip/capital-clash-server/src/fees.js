function calcFees(value, side) {
  const brokerage = Math.min(20, value * 0.0003);
  const stt = value * 0.001;
  const txn = value * 0.0000297;
  const gst = (brokerage + txn) * 0.18;
  const stamp = side === "BUY" ? value * 0.00015 : 0;
  return { brokerage, stt, txn, gst, stamp, total: brokerage + stt + txn + gst + stamp };
}

module.exports = { calcFees };
