const { pool, init } = require("./db");
const { STOCKS, EVENTS } = require("./gameData");
const { matchLimitOrders, payDividends } = require("./trading");
const { tickBusinesses } = require("./business");
const { seedAuctionIfNeeded, resolveAuctions } = require("./auctions");
const { computeLeaderboard } = require("./leaderboard");

const QUARTER_TICKS = 45; // dividends paid every 45 ticks ("game quarter")
const r2 = (n) => Math.round(n * 100) / 100;

function makeCandles(p) {
  let last = p * (0.97 + Math.random() * 0.06);
  const out = [];
  for (let i = 0; i < 50; i++) {
    const o = last;
    const c = o * (1 + (Math.random() - 0.5) * 0.008);
    const h = Math.max(o, c) * (1 + Math.random() * 0.002);
    const l = Math.min(o, c) * (1 - Math.random() * 0.002);
    out.push({ o: r2(o), h: r2(h), l: r2(l), c: r2(c) });
    last = c;
  }
  return out;
}

async function seedStocksIfNeeded() {
  const { rows: [{ c }] } = await pool.query("SELECT COUNT(*)::int c FROM stocks");
  if (c > 0) return;
  for (const s of STOCKS) {
    await pool.query(
      `INSERT INTO stocks (symbol,name,sector,price,div_yield,session_open)
       VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (symbol) DO NOTHING`,
      [s.s, s.n, s.sec, s.p, s.div, s.p]
    );
  }
}

async function createGameLoop(io) {
  await init();
  await seedStocksIfNeeded();

  let t = 0;
  let events = [];
  const market = {};
  STOCKS.forEach((s) => {
    const candles = makeCandles(s.p);
    const price = candles[candles.length - 1].c;
    market[s.s] = { price, sessionOpen: price, haltUntil: null, candles };
  });

  let ticking = false; // guards against overlapping ticks if the DB is briefly slow

  async function tick() {
    if (ticking) return;
    ticking = true;
    try {
      t++;
      const jump = {};
      if (t === 8 || t % 25 === 0) {
        const ev = EVENTS[Math.floor(Math.random() * EVENTS.length)];
        Object.entries(ev.stock).forEach(([sec, v]) => (jump[sec] = v));
        events = [...events.filter((e) => e.until > t), { ...ev, until: t + ev.dur }];
        io.emit("news", { t, text: ev.text });
      }

      for (const st of STOCKS) {
        const m = market[st.s];
        const halted = m.haltUntil && m.haltUntil > t;
        let price = m.price, sessionOpen = m.sessionOpen, haltUntil = halted ? m.haltUntil : null;
        if (t % 60 === 0) sessionOpen = m.price;
        if (!halted) {
          price = r2(Math.max(1, m.price * (1 + (Math.random() - 0.5) * 0.0044) * (1 + (jump[st.sec] || 0))));
          const dev = (price - sessionOpen) / sessionOpen;
          if (Math.abs(dev) >= 0.2) {
            haltUntil = t + 50;
            price = r2(sessionOpen * (1 + Math.sign(dev) * 0.2));
            io.emit("news", { t, text: `${st.s} hits its 20% circuit limit and is halted` });
          } else if (Math.abs(dev) >= 0.1) {
            haltUntil = t + 15;
            io.emit("news", { t, text: `${st.s} hits its 10% circuit limit and pauses` });
          }
        }
        const last = m.candles[m.candles.length - 1];
        const candles = t % 5 === 0
          ? [...m.candles.slice(-59), { o: price, h: price, l: price, c: price }]
          : [...m.candles.slice(0, -1), { ...last, h: Math.max(last.h, price), l: Math.min(last.l, price), c: price }];
        market[st.s] = { price, sessionOpen, haltUntil, candles };
        // Fire-and-forget: price sync isn't on the critical path, and failures
        // here shouldn't stall the whole tick.
        pool.query("UPDATE stocks SET price=$1, session_open=$2, halt_until=$3 WHERE symbol=$4",
          [price, sessionOpen, haltUntil, st.s]).catch((e) => console.error("price sync failed", e.message));
      }

      await matchLimitOrders(market, io);
      if (t % QUARTER_TICKS === 0) await payDividends(market, io);
      if (t % 3 === 0) await tickBusinesses(events.filter((e) => e.until > t));
      await seedAuctionIfNeeded(t, market);
      await resolveAuctions(market, t, io);

      io.emit("market:update", {
        t,
        prices: Object.fromEntries(Object.entries(market).map(([s, m]) => [
          s, { price: m.price, haltUntil: m.haltUntil, candle: m.candles[m.candles.length - 1] },
        ])),
      });

      if (t % 5 === 0) io.emit("leaderboard:update", { leaderboard: await computeLeaderboard(market) });
    } catch (err) {
      console.error("Game loop tick failed:", err);
    } finally {
      ticking = false;
    }
  }

  setInterval(tick, 1000);

  return {
    getMarket: () => market,
    getTick: () => t,
    getEvents: () => events,
  };
}

module.exports = { createGameLoop };
