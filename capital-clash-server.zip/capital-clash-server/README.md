# Capital Clash — going online, for free

This turns the single-player prototype into a real multiplayer game: everyone
who connects trades against the same live market, the same auction house, and
sees the same leaderboard. Total cost: ₹0/month at hobby scale.

## What you're deploying

| Piece | File(s) | Where it runs |
|---|---|---|
| Backend (Express + Socket.io + game loop) | `capital-clash-server/` | Render (free Web Service) |
| Database | Postgres schema in `src/db.js` | Neon or Supabase (free Postgres) |
| Frontend | `CapitalClashOnline.jsx` | Vercel or Netlify (free static hosting) |

**Free-tier trade-off to know up front:** Render's free Web Service spins down
after ~15 minutes with no traffic, and takes 30–60 seconds to wake back up on
the next request. That means the market "pauses" while nobody's playing and
resumes when someone loads the page again — fine for a casual game with
friends, not something you'd want for a always-on public server. If that
matters later, upgrading just the Render service to its cheapest paid tier
(a few dollars a month) removes the spin-down; everything else here stays free.

---

## 1. Database — Neon (free Postgres)

1. Go to neon.tech and sign up (GitHub login is fastest).
2. Create a new project — any name, any region close to you.
3. On the project dashboard, copy the **connection string** it shows you. It
   looks like:
   ```
   postgres://neondb_owner:AbCdEf123@ep-cool-name-12345.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```
4. Keep this tab open — you'll paste this string into Render in step 2.

You don't need to create any tables yourself — the server does that
automatically on first boot (`init()` in `src/db.js`).

(Supabase works identically if you prefer it: Project Settings → Database →
Connection string → "URI".)

## 2. Backend — Render (free Web Service)

1. Push the `capital-clash-server/` folder to a GitHub repo (a new repo just
   for this is simplest).
2. Go to render.com, sign up, click **New → Web Service**, and connect that repo.
3. Settings:
   - **Root directory:** `capital-clash-server` (or wherever `package.json` lives, if you put other things in the same repo)
   - **Build command:** `npm install`
   - **Start command:** `npm start`
   - **Instance type:** Free
4. Under **Environment**, add these variables:
   - `DATABASE_URL` → paste the Neon connection string from step 1
   - `JWT_SECRET` → any long random string (generate one locally: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`)
   - `PGSSL` → `true`
5. Click **Create Web Service**. First deploy takes a few minutes.
6. Once it's live, open `https://your-service-name.onrender.com/health` in a
   browser — you should see `{"ok":true,"t":<some number>}`. That number
   climbing on refresh means the game loop is ticking.

That URL (`https://your-service-name.onrender.com`) is your server address —
you'll enter it as the "Server URL" on the client's login screen.

## 3. Frontend — Vercel (free static hosting)

The client file (`CapitalClashOnline.jsx`) needs to live inside a React
project, since it imports `socket.io-client` and JSX needs a build step.
Quickest path:

```bash
npm create vite@latest capital-clash-client -- --template react
cd capital-clash-client
npm install socket.io-client lucide-react
```

Then:
- Replace the contents of `src/App.jsx` with `CapitalClashOnline.jsx`.
- Make sure Tailwind is set up (or swap the `className`s for your own CSS —
  the component doesn't require Tailwind specifically, it just uses utility
  class names throughout).

Push this project to GitHub, then:
1. Go to vercel.com, sign up, **New Project**, import that repo.
2. Leave all defaults (Vite is auto-detected) and deploy.
3. Open the Vercel URL it gives you, and on the login screen, paste your
   Render URL from step 2 into the **Server URL** field.

Netlify works the same way if you prefer it (drag-and-drop the `dist` folder
after `npm run build`, or connect the repo for automatic deploys).

## 4. Try it

Open your Vercel URL in two different browsers (or one normal + one private
window) and sign up as two different users. Buy shares as one, watch the
order book, dividends, and leaderboard update live in the other. Open a
third tab as an anonymous viewer (skip login, the market/leaderboard routes
are public) to confirm spectators can watch without an account.

---

## Local development (before you deploy anything)

```bash
cd capital-clash-server
cp .env.example .env
# edit .env: paste a Neon connection string (or a local Postgres URL),
# and set PGSSL=false if you're running Postgres locally without SSL
npm install
npm run dev
```

Then run the client against `http://localhost:4000` as the Server URL.

## Extending it

Every feature from the single-player prototype (short selling, circuit
breakers — already included — insider tips, bank loans/margin calls,
business insurance/disasters, player IPOs, hostile takeovers, index futures,
seasonal events, NPC hires, prestige) follows the exact same recipe already
used here: a Postgres table, a function in a module next to `trading.js` or
`business.js`, a route that calls it, and — if it needs to happen on a timer —
a few lines in `gameLoop.js`'s `tick()`. `CAPITAL_CLASH_ARCHITECTURE.md`'s
§5 spells out the schema and logic for each one in detail.
